# /// script
# requires-python = ">=3.14"
# dependencies = []
# ///
# ─── How to run ───
# Run through the actual Template Stage 03 in a governed, source-bound offline job.
# Supply CROSSTALK_TEMPLATE_MANIFEST and its independently reviewed
# CROSSTALK_TEMPLATE_MANIFEST_SHA256. No default or latest manifest is selected.
# Invoke only through the governed project/Template workflow with those same inputs.
# ──────────────────
"""Thin standard-library manuscript hydration entry; this script never renders PDFs."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Final

ROOT: Final = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from crosstalk.template_io import digest  # noqa: E402 -- Project source precedes analysis environments.
from crosstalk.template_projection import generate_projection  # noqa: E402
from crosstalk.template_records import ManifestSelection, ProjectionError, ProjectionRequest  # noqa: E402


def main() -> None:
    """The launcher, not the projection, owns execution admission and actual render acceptance."""
    path = os.environ.get("CROSSTALK_TEMPLATE_MANIFEST")
    expected = os.environ.get("CROSSTALK_TEMPLATE_MANIFEST_SHA256")
    if not path or not expected:
        raise ProjectionError(
            "explicit manifest path and independently supplied SHA-256 are required"
        )
    run = generate_projection(
        ProjectionRequest(ROOT, ManifestSelection(Path(path), digest(expected)))
    )
    _ = sys.stdout.write(
        f"Native Template inputs: projection={run.projection_sha256} "
        + f"source_rows={run.inventory_rows} body_figures={run.body_figures}; "
        + "PDF rendering pending\n"
    )


if __name__ == "__main__":
    main()
