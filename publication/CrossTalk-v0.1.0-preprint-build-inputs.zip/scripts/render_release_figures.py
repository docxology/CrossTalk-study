"""Render five CrossTalk figures from public study tables and aggregate cells."""
import argparse
from collections import Counter, defaultdict
import csv
from hashlib import sha256
import json
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.pdfgen.canvas import Canvas


INK = "#191919"
SECONDARY = "#5A5A5A"
RULE = "#D0D0D0"
LIGHT = "#EBEBEB"
PAPER = "#FFFFFF"
RED = "#B00020"
WIDTH = 620
ERAS = ((1989, 1994), (1995, 1999), (2000, 2009), (2010, 2019), (2020, 2025))
TYPE = {"native": INK, "ocr-only": "#8B8B8B", "none": "#E3E3E3"}
TITLES = {
    "ga01_sourceframe": "The retained issues by year",
    "ga02_language": "How text becomes searchable",
    "ga03_pagemorphology": "Four patterns of page layout",
    "ga04_evidencematrix": "What the evidence covers",
    "retained_open_scope_v103": "Pages and articles in eleven open issues",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def csv_rows(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def nfmt(count):
    return f"{count:,}"


def pct(numerator, denominator):
    return f"{100 * numerator / denominator:.1f}%"


class Plate:
    """Draw in points using a top-left origin."""

    def __init__(self, path, height, title):
        self.canvas = Canvas(str(path), pagesize=(WIDTH, height), invariant=1, pageCompression=1)
        self.canvas.setTitle(title)
        self.canvas.setAuthor("Daniel Ari Friedman")
        self.height = height
        self.box(0, 0, WIDTH, height, PAPER)

    def write(self, x, y, text, size=11, *, font="Helvetica", color=INK, align="left"):
        self.canvas.setFont(font, size)
        self.canvas.setFillColor(HexColor(color))
        method = {"left": self.canvas.drawString, "right": self.canvas.drawRightString,
                  "center": self.canvas.drawCentredString}[align]
        method(x, self.height - y, str(text))

    def line(self, x, y, x_end, y_end, color=RULE, width=0.6):
        self.canvas.setStrokeColor(HexColor(color))
        self.canvas.setLineWidth(width)
        self.canvas.line(x, self.height - y, x_end, self.height - y_end)

    def box(self, x, y, width, height, fill, border=None, stroke=0.5):
        self.canvas.setFillColor(HexColor(fill))
        if border:
            self.canvas.setStrokeColor(HexColor(border))
            self.canvas.setLineWidth(stroke)
        self.canvas.rect(x, self.height - y - height, width, height, fill=1, stroke=int(bool(border)))

    def heading(self, label, title, sub, *, dark=False):
        if dark:
            self.box(0, 0, WIDTH, 86, INK)
        else:
            self.line(23, 82, 597, 82)
        self.box(23, 18, 19, 3, "#EA4B5F" if dark else RED)
        self.write(49, 23, label, 9.5, font="Courier-Bold", color=PAPER if dark else SECONDARY)
        self.write(23, 51, title, 24, font="Helvetica-Bold", color=PAPER if dark else INK)
        self.write(23, 70, sub, 11, color=LIGHT if dark else SECONDARY)

    def footnote(self, y, text):
        self.write(23, y, text, 10, color=SECONDARY)

    def save(self):
        self.canvas.showPage()
        self.canvas.save()


class Measurements:
    def __init__(self, tables):
        front_rows = csv_rows(tables / "crosstalk-cover-inventory.csv")
        issues = csv_rows(tables / "crosstalk-issue-inventory.csv")
        pages = csv_rows(tables / "crosstalk-page-measures.csv")
        self.priority = csv_rows(tables / "priority-issue-counts.csv")
        self.open = csv_rows(tables / "retained-open-scope-census.csv")
        self.scope = json.loads((tables / "figure-and-data-scope.json").read_text(encoding="utf-8"))
        self.issues = {r["issue_id"]: r for r in issues}
        self.fronts = sorted(front_rows, key=lambda r: int(r["position_one_based"]))
        self.pages = defaultdict(list)
        signatures = set()
        for row in pages:
            issue = self.issues[row["issue_id"]]
            require(row["pdf_sha256"] == issue["pdf_sha256"], "Page source digest mismatch")
            position = (row["issue_id"], int(row["position_zero_based"]))
            require(position not in signatures, "Duplicate physical page")
            signatures.add(position)
            self.pages[row["issue_id"]].append(row)
        require(len(self.issues) == len(issues) == len(self.fronts) == self.scope["retained_issues"],
                "Issue inventories disagree")
        require({r["issue_id"] for r in self.fronts} == set(self.issues) == set(self.pages),
                "Issue universe mismatch")
        require([int(row["position_one_based"]) for row in self.fronts] == list(range(1, len(issues) + 1)),
                "Cover order is not contiguous")
        for issue_id, rows in self.pages.items():
            require({int(r["position_zero_based"]) for r in rows} == set(range(int(self.issues[issue_id]["pages"]))),
                    f"Incomplete physical page positions for {issue_id}")
        self.open_ids = {r["issue_id"] for r in self.open}
        for row in self.open:
            authority = self.issues[row["issue_id"]]
            require(authority["pdf_sha256"] == row["pdf_sha256"] and authority["pages"] == row["physical_pages"],
                    "Open-scope row differs from the issue inventory")
            require(not row["original_print_bodies"], "An admitted historical original count needs new accounting")
        self.counts = Counter(r["admitted_text_source"] for r in pages)
        self.page_count = len(pages)
        self.roles = Counter(r["article_reading_role"] for r in pages)
        self.groups = Counter(r["shape_group"] for r in pages)
        self.group_issue_counts = Counter()
        self.weights = Counter()
        for rows in self.pages.values():
            counts = Counter(r["shape_group"] for r in rows)
            for group, count in counts.items():
                self.group_issue_counts[group] += 1
                self.weights[group] += count / len(rows)
        self.by_year = defaultdict(list)
        self.era_pages = defaultdict(Counter)
        for front in self.fronts:
            year = int(front["date"][:4])
            self.by_year[year].append(front)
            era, = [bounds for bounds in ERAS if bounds[0] <= year <= bounds[1]]
            self.era_pages[era].update(row["admitted_text_source"] for row in self.pages[front["issue_id"]])
        self.exact_priority = sum(bool(row["exact_scope_article_count"]) for row in self.priority)
        self.exact = len(self.issues) - len(self.open_ids)
        require(self.exact == self.scope["exact_retained_issue_scopes"] and len(self.open_ids) == len(self.open),
                "Exact issue scope totals disagree")
        require(self.page_count == self.scope["physical_pages"] and self.counts.total() == self.page_count,
                "Physical page counts disagree")
        require(self.roles["direct-reading-reach"] == self.scope["complete_appraisal_direct_reach_pages"],
                "Direct reading count differs from the released scope")
        require(set(self.counts) == set(TYPE) and set(self.groups) == {"1", "2", "3", "4"},
                "Unexpected measurement categories")
        require(abs(sum(self.weights.values()) - len(self.issues)) < 1e-8,
                "Equal issue weights do not sum to the number of issues")


def cover_tile(plate, x, y, role, external, unresolved):
    fill = "#B9B9B9" if role == "front-cover" else PAPER
    plate.box(x, y, 6.6, 9.2, fill, RED if unresolved else SECONDARY, 0.85 if unresolved else 0.4)
    plate.line(x + 1.2, y + 2.15, x + 5.4, y + 2.15, SECONDARY, 0.35)
    if external:
        plate.line(x + 0.4, y + 8.8, x + 6.2, y + 0.4, INK, 0.47)


def cover(path, d):
    count = len(d.fronts)
    title = TITLES["ga01_sourceframe"]
    plate = Plate(path, 350, title)
    plate.heading("CROSSTALK / ISSUE FRONTS", title,
                  f"One drawn glyph for each of {nfmt(count)} retained issue PDFs, 1989-2025.", dark=True)
    for index, (first, last) in enumerate(ERAS):
        base = 105 + 42 * index
        for column, year in enumerate(range(first, last + 1)):
            x = 26 + 57 * column
            record = d.by_year[year]
            plate.write(x, base, str(year), 9.8, font="Helvetica-Bold", color=INK if record else SECONDARY)
            for tile, front in enumerate(record):
                row, col = divmod(tile, 6)
                require(row < 2, f"Cover layout too small for {year}")
                cover_tile(plate, x + 7.8 * col, base + 4 + row * 10.6, front["mosaic_role"],
                           front["mosaic_image_basis"] != "retained-pdf", front["issue_id"] in d.open_ids)
        plate.line(23, base + 28, 597, base + 28)
    swatches = (
        (25, "front-cover", False, False, "Cover"),
        (121, "issue-front-page", False, False, "Newsletter front"),
        (277, "front-cover", True, False, "Separate publisher image"),
        (463, "issue-front-page", False, True, "Original scope open"),
    )
    for x, role, external, unresolved, label in swatches:
        cover_tile(plate, x, 320, role, external, unresolved)
        plate.write(x + 12, 328, label, 9.7)
    plate.save()


def lexical(path, d):
    title = TITLES["ga02_language"]
    plate = Plate(path, 534, title)
    plate.heading("GRAPHICAL ABSTRACT / TEXT", title,
                  "Native text, optical character recognition (OCR) and pages with neither.")
    plate.write(23, 109, "Composition of each retained PDF", 14, font="Helvetica-Bold")
    plate.footnote(127, "Equal-width columns follow retained-issue order, including combined issues.")
    x0, x1, top, height = 55, 594, 149, 155
    for share in (0, 25, 50, 75, 100):
        y = top + height * (1 - share / 100)
        plate.line(x0, y, x1, y)
        plate.write(x0 - 6, y + 3.0, f"{share}%", 8.8, align="right", color=SECONDARY)
    baseline = top + height
    width = (x1 - x0) / len(d.fronts)
    ticks = {1989, 1995, 2000, 2005, 2010, 2015, 2020, 2025}
    for index, front in enumerate(d.fronts):
        rows = d.pages[front["issue_id"]]
        counts = Counter(r["admitted_text_source"] for r in rows)
        x = x0 + index * width
        y = baseline
        for kind, color in TYPE.items():
            span = height * counts[kind] / len(rows)
            if span:
                y -= span
                plate.box(x, y, width + 0.12, span, color)
        year = int(front["date"][:4])
        if year in ticks:
            plate.line(x, baseline + 0.7, x, baseline + 4.7, RULE)
            align = "right" if year == 2025 else "left"
            label_y = baseline + (27 if year == 2025 else 16)
            plate.write(x, label_y, year, 8.8, color=SECONDARY, align=align)
            ticks.remove(year)
    plate.write(23, 351, "Page-weighted totals by era", 14, font="Helvetica-Bold")
    for index, era in enumerate(ERAS):
        y = 369 + index * 20
        counts = d.era_pages[era]
        total = counts.total()
        plate.write(23, y + 6, f"{era[0]}-{era[1]}", 10.5, font="Helvetica-Bold")
        plate.box(107, y - 3, 368, 10, PAPER, RULE)
        x = 107
        for kind, color in TYPE.items():
            span = 368 * counts[kind] / total
            if span:
                plate.box(x, y - 3, span, 10, color)
                x += span
        plate.write(597, y + 6, f"{nfmt(total)} pages", 10, color=SECONDARY, align="right")
    for x, (kind, label) in zip((23, 208, 410),
                                (("native", "native"), ("ocr-only", "OCR only"), ("none", "without text"))):
        plate.box(x, 483, 10, 10, TYPE[kind], RULE)
        count = d.counts[kind]
        plate.write(x + 15, 492, f"{nfmt(count)} {label} ({pct(count, d.page_count)})", 10.5)
    plate.footnote(515, "Admitted text can be as short as a running header. It does not establish article completeness.")
    plate.save()


def shape(path, d, source):
    title = TITLES["ga03_pagemorphology"]
    plate = Plate(path, 522, title)
    plate.heading("GRAPHICAL ABSTRACT / PAGE APPEARANCE", title,
                  f"Each layout map pools members of one group across {nfmt(d.page_count)} pages.")
    plate.write(23, 112, "Mean darkness in a common page frame", 14, font="Helvetica-Bold")
    plate.footnote(131, "Coarse cells summarize each group's aggregate map. All four use the same grayscale.")
    panels = source["group_cells"]
    columns, rows = source["grid"]
    cell = 9.75
    for index, (group, matrix) in enumerate(panels.items()):
        x = 23 + index * 148
        require(len(matrix) == rows and {len(row) for row in matrix} == {columns}, "Invalid aggregate matrix")
        for r, row in enumerate(matrix):
            for c, value in enumerate(row):
                require(isinstance(value, int) and 0 <= value <= 255, "Aggregate cell out of range")
                shade = f"#{value:02x}{value:02x}{value:02x}"
                plate.box(x + c * cell, 151 + r * cell, cell, cell, shade)
        plate.canvas.setStrokeColor(HexColor(SECONDARY))
        plate.canvas.setLineWidth(0.5)
        plate.canvas.rect(x, plate.height - 151 - rows * cell, columns * cell, rows * cell, fill=0)
        base = 151 + rows * cell
        plate.write(x, base + 23, f"GROUP {int(group):02}", 10, font="Courier-Bold")
        plate.write(x, base + 46, f"{nfmt(d.groups[group])} pages", 14, font="Helvetica-Bold")
        plate.write(x, base + 65, f"{pct(d.weights[group], len(d.issues))} issue-weighted", 10, color=RED)
        plate.write(x, base + 82, f"{nfmt(d.group_issue_counts[group])} issues present", 10, color=SECONDARY)
    plate.line(23, 447, 597, 447)
    plate.footnote(465, "Each issue contributes the same total weight. Group numbers run from lightest to darkest.")
    plate.footnote(482, "Five refits held out whole issues. Adjusted Rand agreement on held-out pages was 0.99-1.00.")
    plate.footnote(500, "These patterns describe retained page appearance, including digitization and scan effects.")
    plate.save()


def coverage_bar(plate, x, y, width, label, numerator, denominator, *, highlight=False):
    plate.write(x, y, label, 11.1, font="Helvetica-Bold")
    metric = f"{nfmt(numerator)} / {nfmt(denominator)}  ({pct(numerator, denominator)})"
    plate.write(x + width, y, metric, 10.6, align="right")
    plate.box(x, y + 8, width, 6, LIGHT)
    plate.box(x, y + 8, width * numerator / denominator, 6, INK)
    if highlight and denominator > numerator:
        filled = width * numerator / denominator
        plate.box(x + filled, y + 8, width - filled, 6, RED)


def coverage(path, d):
    title = TITLES["ga04_evidencematrix"]
    plate = Plate(path, 518, title)
    plate.heading("GRAPHICAL ABSTRACT / COVERAGE", title,
                  "Page measurement, full-article reading and exact censuses have different units.")
    plate.write(23, 110, "Pages within the retained material", 14, font="Helvetica-Bold")
    n = d.page_count
    coverage_bar(plate, 23, 138, 574, "Visual measurement", n, n)
    coverage_bar(plate, 23, 176, 574, "Admitted text", n - d.counts["none"], n)
    coverage_bar(plate, 23, 214, 574, "Direct reach of complete article appraisals",
                 d.roles["direct-reading-reach"], n)
    plate.write(23, 263, "Exact article censuses within issue sets", 14, font="Helvetica-Bold")
    coverage_bar(plate, 23, 290, 574, "Retained issue scopes", d.exact, len(d.issues), highlight=True)
    coverage_bar(plate, 23, 328, 574, "Originally open priority set", d.exact_priority, len(d.priority), highlight=True)
    plate.box(23, 378, 278, 96, "#F2F2F2")
    plate.box(319, 378, 278, 96, "#F2F2F2")
    plate.write(36, 414, nfmt(d.scope["distinct_complete_ai_assisted_article_appraisals"]),
                27, font="Helvetica-Bold")
    plate.write(36, 434, "Distinct complete appraisals", 12, font="Helvetica-Bold")
    plate.write(36, 453, "AI-assisted full-body reading", 10.5, color=SECONDARY)
    plate.write(332, 414, nfmt(len(d.open)), 27, font="Helvetica-Bold", color=RED)
    plate.write(332, 434, "Original print scopes open", 12, font="Helvetica-Bold")
    held_pages = sum(int(row["physical_pages"]) for row in d.open)
    held_bodies = sum(int(row["complete_bodies"]) for row in d.open)
    plate.write(332, 453, f"{held_pages} retained pages / {held_bodies} confirmed bodies", 10.5, color=SECONDARY)
    plate.footnote(497, "Historical totals for issues and original print articles remain unknown.")
    plate.save()


def open_scopes(path, d):
    title = TITLES["retained_open_scope_v103"]
    plate = Plate(path, 417, title)
    plate.heading("CROSSTALK / OPEN ORIGINAL PRINT SCOPES", title,
                  "Each row describes retained material. Original print article counts remain unknown.")
    plate.write(23, 108, "Issue", 11, font="Helvetica-Bold")
    plate.write(129, 108, "Retained physical pages", 11, font="Helvetica-Bold")
    plate.write(338, 108, "Confirmed complete bodies", 11, font="Helvetica-Bold")
    plate.write(596, 108, "Partial / disputed", 10.2, font="Helvetica-Bold", align="right")
    x0, x1 = 129, 338
    sw_page, sw_body = 162, 155
    start, bottom = 130, 352
    for x, span, cap, ticks in ((x0, sw_page, 50, (0, 10, 20, 30, 40, 50)),
                                 (x1, sw_body, 15, (0, 5, 10, 15))):
        for value in ticks:
            pos = x + span * value / cap
            plate.write(pos, start - 7, value, 8.3, align="center", color=SECONDARY)
            plate.line(pos, start - 2, pos, bottom, "#E5E5E5")
    for index, row in enumerate(d.open):
        y = start + 7 + index * 20.1
        plate.write(23, y + 7, row["issue_period"], 10.2, font="Courier-Bold")
        pages = int(row["physical_pages"])
        bodies = int(row["complete_bodies"])
        embedded = int(row["embedded_web_bodies"])
        require(0 <= embedded <= bodies <= 15 and 0 < pages <= 50, "Count exceeds plotted scale")
        plate.box(x0, y - 1, sw_page * pages / 50, 9, "#8B8B8B")
        plate.write(x0 + sw_page * pages / 50 + 5, y + 7, pages, 9.6)
        if bodies - embedded:
            plate.box(x1, y - 1, sw_body * (bodies - embedded) / 15, 9, INK)
        if embedded:
            plate.box(x1 + sw_body * (bodies - embedded) / 15, y - 1, sw_body * embedded / 15, 9, "#AEAEAE")
        plate.write(x1 + sw_body * bodies / 15 + 5, y + 7, bodies, 9.6)
        partial = row["registered_partial_bodies"] or "-"
        disputed = row["disputed_regions"] or "-"
        metric_color = RED if any(value not in ("-", "0") for value in (partial, disputed)) else SECONDARY
        plate.write(596, y + 7, f"{partial}  /  {disputed}", 9.6, color=metric_color, align="right")
    plate.box(23, 370, 10, 10, INK)
    plate.write(38, 379, "Complete retained body", 9.6)
    plate.box(182, 370, 10, 10, "#AEAEAE")
    plate.write(197, 379, "Embedded web body", 9.6)
    plate.footnote(399, "A dash in the last column means no value was recorded. Zero is an observed count.")
    plate.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tables", type=Path, required=True)
    parser.add_argument("--shapes", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    opts = parser.parse_args()
    d = Measurements(opts.tables)
    group_source = json.loads(opts.shapes.read_text(encoding="utf-8"))
    require(sorted(group_source["group_cells"]) == sorted(d.groups), "Visual groups differ from page classifications")
    output = opts.output
    (output / "assets").mkdir(parents=True, exist_ok=True)
    designs = {
        "ga01_sourceframe": ("ga01.pdf", cover,
            "Glyphs place every retained issue under its recorded year. Fill identifies the front type, a diagonal marks a separately sourced publisher image, and a red outline marks an open original print scope.",
            "A year-labeled chronological atlas of 281 synthetic issue-front glyphs. Eleven red outlines identify open original print scopes."),
        "ga02_language": ("ga02.pdf", lexical,
            "Thin columns show each retained PDF in chronological issue order. The era bars give each physical page equal weight. The two views distinguish native text, OCR-only text and no admitted text.",
            "Chronological stacks and five era summaries show 7,102 native pages, 2,539 OCR-only pages, and 19 without admitted text."),
        "ga03_pagemorphology": ("ga03.pdf", lambda path, data: shape(path, data, group_source),
            "These common-scale maps show twelve by seventeen cells from each study-authored aggregate raster. Group sizes and issue-weighted shares describe retained page appearance.",
            "Four coarse grayscale layout maps. The largest group contains 8,865 pages and 92.8 percent of issue-normalized weight."),
        "ga04_evidencematrix": ("ga04.pdf", coverage,
            "Each bar names its denominator. Page measurements, exact issue censuses and the distinct complete-appraisal register answer different coverage questions.",
            "Visual measurements cover all 9,660 retained pages. Exact censuses cover 270 of 281 retained issue scopes and 148 of 158 priority scopes. Eleven original print scopes remain open."),
        "retained_open_scope_v103": ("retained-open-scope.pdf", open_scopes,
            "The eleven open print scopes preserve 197 physical PDF pages and 66 confirmed complete bodies, including three embedded web bodies. The last column records partial bodies and disputed regions where enumerated.",
            "Eleven retained issues have aligned horizontal bars for physical pages and confirmed complete bodies, with a separate pair of partial and disputed counts."),
    }
    specs = {}
    for key, (filename, draw, caption, alt) in designs.items():
        asset = Path("assets") / filename
        draw(output / asset, d)
        specs[key] = {"asset": asset.as_posix(), "title": TITLES[key], "caption": caption, "alt": alt,
                      "sha256": digest(output / asset)}
    table_names = ("crosstalk-cover-inventory.csv", "crosstalk-issue-inventory.csv", "crosstalk-page-measures.csv",
                   "priority-issue-counts.csv", "retained-open-scope-census.csv", "figure-and-data-scope.json")
    receipt = {
        "schema": "crosstalk.public-figure-refresh.v1",
        "figures": specs,
        "input_tables_sha256": {name: digest(opts.tables / name) for name in table_names},
        "aggregate_cells_sha256": digest(opts.shapes),
        "source_page_reproductions": 0,
        "expected_visual_aggregate_images": 0,
    }
    (output / "visual-spec.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
