"""Render a rights-cleared chart from the released alignment measures."""
import argparse
import csv
from decimal import Decimal
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.pdfgen.canvas import Canvas


def metrics(csv_path):
    with csv_path.open(newline="", encoding="utf-8") as source:
        rows = list(csv.DictReader(source))
    return {row["metric"]: int(row["value"]) for row in rows}


def render(source, destination):
    values = metrics(source)
    total = values["journal_ocr_positions"]
    covered = values["positions_in_exact_blocks"]
    share = Decimal(covered) * 100 / total
    remaining = total - covered
    rows = [(width, values[f"shared_windows_{width}"]) for width in (4, 5, 6, 8, 12, 25, 50)]

    ink, secondary, rule, soft, red = map(HexColor, ("#191919", "#5A5A5A", "#D0D0D0", "#EBEBEB", "#B00020"))
    canvas = Canvas(str(destination), pagesize=(620, 355), invariant=True, pageCompression=1)
    canvas.setTitle("Exact wording across two 1992 versions")
    canvas.setAuthor("Daniel Ari Friedman")

    def label(x, y, value, size=10, color=ink, face="Helvetica", align="left"):
        canvas.setFillColor(color)
        canvas.setFont(face, size)
        methods = {"left": canvas.drawString, "right": canvas.drawRightString, "center": canvas.drawCentredString}
        methods[align](x, y, value)

    def box(x, y, width, height, color):
        canvas.setFillColor(color)
        canvas.rect(x, y, width, height, stroke=0, fill=1)

    def line(x0, y0, x1, y1, color=rule, weight=0.55):
        canvas.setStrokeColor(color)
        canvas.setLineWidth(weight)
        canvas.line(x0, y0, x1, y1)

    x, end = 25, 595
    line(x, 331, end, 331, ink, 0.75)
    box(x, 323, 28, 3, red)
    label(x, 296, "Exact wording across two 1992 versions", 25, face="Helvetica-Bold")
    label(x, 278, "March CrossTalk article and Charles A. Jennings's reengineering appendix", 11, secondary)
    label(x, 252, "Journal OCR word positions", 11, face="Helvetica-Bold")
    label(end, 252, f"{total:,} total", 10, secondary, align="right")
    bar_y, bar_h, bar_w = 226, 17, end - x
    filled = bar_w * covered / total
    box(x, bar_y, bar_w, bar_h, soft)
    box(x, bar_y, filled, bar_h, ink)
    label(x+7, bar_y+5, f"{share:.2f}%", 10, HexColor("#FFFFFF"), "Helvetica-Bold")
    label(x, 209, f"{covered:,} in exact blocks of at least {values['minimum_block_words']} words", 9.5)
    label(end, 209, f"{remaining:,} outside qualifying blocks", 9.5, secondary, align="right")
    line(x, 195, end, 195)
    line(229, 43, 229, 181)

    label(x, 176, "Longest exact block", 11, face="Helvetica-Bold")
    label(x, 126, str(values["longest_exact_block_words"]), 49, red, "Helvetica-Bold")
    label(x+88, 129, "words", 14, face="Helvetica-Bold")
    label(x, 100, f"Journal folio {values['longest_block_journal_folio']}", 11)
    label(x, 83, f"Thesis page {values['longest_block_thesis_page']}", 11)
    label(x, 59, "Longest block observed by the", 9, secondary)
    label(x, 46, "page-bounded alignment.", 9, secondary)

    label(246, 176, "Shared distinct word sequences", 11, face="Helvetica-Bold")
    run_x, run_w = 294, 248
    axis_max = 2000
    for tick in (0, 1000, 2000):
        px = run_x + tick * run_w / axis_max
        line(px, 59, px, 161)
        label(px, 45, f"{tick:,}", 8.5, secondary, align="center")
    for index, (width, count) in enumerate(rows):
        y = 153 - index*14
        color = red if width == 50 else ink
        box(run_x, y, count * run_w / axis_max, 5, color)
        label(286, y-1, f"{width} words", 8.5, color, align="right")
        label(587, y-1, f"{count:,}", 8.5, color, "Helvetica-Bold", "right")

    line(x, 32, end, 32)
    label(x, 17, "Sources: CrossTalk, printed folios 7-10. Jennings thesis, printed pp. 84-95.", 8.5, secondary)
    canvas.showPage()
    canvas.save()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("pdf", type=Path)
    arguments = parser.parse_args()
    render(arguments.csv, arguments.pdf)
