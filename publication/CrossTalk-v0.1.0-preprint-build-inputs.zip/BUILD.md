# CrossTalk preprint inputs

Study edition 0.1.0. The Zenodo version DOI is 10.5281/zenodo.24297224.

Place these files in a clean checkout of the companion public source bundle. The inputs include the projection entry point, one inventory, four graphical abstracts and
ten analysis figures, with their exact digests. No source page image is required
for this preprint build. The four aggregate darkness maps on page 3 are coarse vector grids.

Clone [docxology Template](https://github.com/docxology/template) and check out the publicly accessible engine revision `f89cd527c7c688b9d67a995d584e026b2b5ccaab`. The verified render used Pandoc 3.14, pandoc-crossref 0.3.26 and XeLaTeX from TeX Live 2026.

```sh
git clone https://github.com/docxology/template.git Template
git -C Template checkout --detach f89cd527c7c688b9d67a995d584e026b2b5ccaab
study="$(pwd -P)"
(cd Template && uv sync --locked --no-dev)
mkdir -p Template/projects/working
ln -s "$study" Template/projects/working/Preprint
```

Invoke CrossTalk's manuscript projection with these explicit inputs:

```sh
export CROSSTALK_TEMPLATE_MANIFEST="$PWD/docs/template-render-inputs-v0.1.0.csv"
export CROSSTALK_TEMPLATE_MANIFEST_SHA256=c2b22fc71fa470c3bd0136334975d210be32fd86eb872d549578c52656c17056
Template/.venv/bin/python scripts/z_generate_manuscript_variables.py
```

Run Template Stage 03 using the same project name:

```sh
(cd Template && TEMPLATE_REPO_ROOT="$PWD" TEMPLATE_SKIP_LINK_SYNC=1 SOURCE_DATE_EPOCH=1794873600   .venv/bin/python scripts/pipeline/stage_03_render.py --project working/Preprint --skip-manuscript-hydration)
```

The combined PDF is written to `output/pdf/Preprint_combined.pdf`.
The original validation record includes the
engine commit, render manifest, PDF hashes, and inspected physical pages.
The visual and body figure data preserve their own evidence denominators.

## Rebuild the six revised figures

The preprint build uses the exact verified figure files. To regenerate the
revised figures, use Python with ReportLab 4.4.9 and extract the companion
Zenodo data ZIP into a directory named release-data.

```sh
python scripts/render_release_figures.py --tables release-data   --shapes release-data/aggregate-density-cells.json --output regenerated-figures
python scripts/make_march_method_panel.py release-data/march-method-alignment.csv   regenerated-figures/march-method-alignment.pdf
```

The scripts draw from study measurements and do not require journal scans.

The versioned [GitHub source](https://github.com/docxology/CrossTalk-study/tree/v0.1.0) accompanies the [Zenodo preprint and data](https://doi.org/10.5281/zenodo.24297224).
